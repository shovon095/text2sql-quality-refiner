"""
Loss components.

L_point (Eq. 9):   per-frame MSE between teacher circuit and projected student circuit
L_trans (Eq. 10):  per-pair MSE on adjacent-frame transitions
L_dir   (new):     1 - cos(Delta^T, W * Delta^S)  -- direction alignment, novel for VLM
L_KD:              KL on output token logits with temperature
L_CE:              standard next-token cross-entropy from the LM head
"""
from __future__ import annotations
from typing import List

import torch
import torch.nn as nn
import torch.nn.functional as F


def _valid_frame_mask(B: int, F_max: int, frame_lens: List[int], device) -> torch.Tensor:
    """Boolean mask [B, F_max] marking real (non-padded) frames."""
    m = torch.zeros(B, F_max, dtype=torch.bool, device=device)
    for b, n in enumerate(frame_lens):
        m[b, :n] = True
    return m


def loss_point(
    C_T_per_layer: List[torch.Tensor],     # length L_T, each [B, F, D_T]
    C_S_per_layer: List[torch.Tensor],     # length L_T (already depth-mapped), each [B, F, D_S]
    projection,                            # LayerwiseProjection
    frame_lens: List[int],
) -> torch.Tensor:
    """
    Eq. (9):  L_point = (1/|V|) * sum_l sum_f || C^T_l(f) - W_l C^S_{f(l)}(f) ||_2^2
    """
    device = C_T_per_layer[0].device
    B, F_max, _ = C_T_per_layer[0].shape
    mask = _valid_frame_mask(B, F_max, frame_lens, device)         # [B, F]
    total = C_T_per_layer[0].new_zeros(())
    denom = mask.sum().clamp(min=1).float()
    for l, (cT, cS) in enumerate(zip(C_T_per_layer, C_S_per_layer)):
        projected = projection(cS, l)                              # [B, F, D_T]
        diff = (cT - projected).pow(2).sum(dim=-1)                 # [B, F]
        total = total + (diff * mask.float()).sum()
    return total / (denom * len(C_T_per_layer))


def loss_trans(
    dT_per_layer: List[torch.Tensor],      # each [B, F-1, D_T]
    dS_per_layer: List[torch.Tensor],      # each [B, F-1, D_S]
    projection,
    frame_lens: List[int],
) -> torch.Tensor:
    """
    Eq. (10): L_trans = (1/|P|) * sum_l sum_f || Delta^T_l(f) - W_l Delta^S_{f(l)}(f) ||_2^2
    """
    device = dT_per_layer[0].device
    B, P_max, _ = dT_per_layer[0].shape
    # valid pair count per sample = max(0, frame_len - 1)
    pair_lens = [max(0, n - 1) for n in frame_lens]
    mask = _valid_frame_mask(B, P_max, pair_lens, device)          # [B, P]
    total = dT_per_layer[0].new_zeros(())
    denom = mask.sum().clamp(min=1).float()
    for l, (dT, dS) in enumerate(zip(dT_per_layer, dS_per_layer)):
        projected = projection(dS, l)                              # [B, P, D_T]
        diff = (dT - projected).pow(2).sum(dim=-1)                 # [B, P]
        total = total + (diff * mask.float()).sum()
    return total / (denom * len(dT_per_layer))


def loss_direction(
    dT_per_layer: List[torch.Tensor],
    dS_per_layer: List[torch.Tensor],
    projection,
    frame_lens: List[int],
) -> torch.Tensor:
    """
    Novel for VLM: cosine-similarity alignment of transition direction.
    Behaviors are *signed* (pick up vs. put down), so direction matters,
    not just magnitude.
    """
    device = dT_per_layer[0].device
    B, P_max, _ = dT_per_layer[0].shape
    pair_lens = [max(0, n - 1) for n in frame_lens]
    mask = _valid_frame_mask(B, P_max, pair_lens, device).float()
    total = dT_per_layer[0].new_zeros(())
    denom = mask.sum().clamp(min=1)
    for l, (dT, dS) in enumerate(zip(dT_per_layer, dS_per_layer)):
        projected = projection(dS, l)
        cos = F.cosine_similarity(dT, projected, dim=-1)           # [B, P]
        total = total + ((1.0 - cos) * mask).sum()
    return total / (denom * len(dT_per_layer))


def loss_kd_logits(
    student_logits: torch.Tensor,      # [B, T, V]
    teacher_logits: torch.Tensor,      # [B, T, V]
    labels_mask: torch.Tensor,         # [B, T] bool — only loss-bearing positions
    temperature: float = 3.0,
) -> torch.Tensor:
    """
    Standard temperature-scaled KL over the response positions only.
    """
    T = temperature
    s = F.log_softmax(student_logits / T, dim=-1)
    t = F.softmax(teacher_logits / T, dim=-1)
    kl = F.kl_div(s, t, reduction="none").sum(dim=-1)              # [B, T]
    kl = (kl * labels_mask.float()).sum() / labels_mask.float().sum().clamp(min=1)
    return kl * (T * T)
