"""
Stage 3: evaluate on Mementos using their GPT-4 keyword extraction pipeline.

This script generates captions for every test sequence; the actual object/behavior
F1 computation is done by Mementos' provided notebook
(GPT-4-assisted_evaluation.ipynb in their repo).

Usage:
    python scripts/03_eval_mementos.py --config config.yaml \
        --student_path ./runs/circuit_vlm_v1/student_final \
        --out preds.jsonl
"""
import argparse
import json
import torch
import yaml
from transformers import AutoProcessor, AutoModelForVision2Seq

from circuit_vlm.data.mementos_dataset import MementosDataset


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--student_path", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--split", default="test")
    args = ap.parse_args()
    cfg = yaml.safe_load(open(args.config))

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    proc = AutoProcessor.from_pretrained(args.student_path)
    model = AutoModelForVision2Seq.from_pretrained(
        args.student_path, torch_dtype=torch.float16
    ).to(device).eval()

    dataset = MementosDataset(cfg["mementos_root"], args.split, proc,
                              max_frames=cfg["max_frames"])

    with open(args.out, "w") as f:
        for i in range(len(dataset)):
            sample = dataset[i]
            input_ids = sample["input_ids"].unsqueeze(0).to(device)
            pixel_values = sample["pixel_values"].to(device, dtype=torch.float16)
            # mask out the caption part so the model has to generate it
            # (find ASSISTANT: position from `labels`)
            mask_idx = (sample["labels"] != -100).nonzero(as_tuple=False)
            if len(mask_idx) > 0:
                first_resp = int(mask_idx[0].item())
                input_ids = input_ids[:, :first_resp]
            with torch.no_grad():
                gen = model.generate(
                    input_ids=input_ids,
                    pixel_values=pixel_values,
                    max_new_tokens=256,
                    do_sample=False,
                )
            text = proc.tokenizer.decode(gen[0][input_ids.shape[1]:],
                                         skip_special_tokens=True)
            f.write(json.dumps({"id": dataset.entries[i]["id"],
                                "prediction": text}) + "\n")
            if i % 25 == 0:
                print(f"[{i}/{len(dataset)}]")

    print(f"Wrote predictions to {args.out}")
    print("Now run Mementos' GPT-4-assisted_evaluation.ipynb on this file.")


if __name__ == "__main__":
    main()
