"""
Stage 2: train the student with circuit-guided KD.

Usage:
    python scripts/02_train.py --config config.yaml
"""
import argparse
from circuit_vlm.training.trainer import train

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    args = ap.parse_args()
    train(args.config)
