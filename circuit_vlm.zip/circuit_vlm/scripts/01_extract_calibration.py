"""
Stage 1: extract task-aware head importance masks from the teacher.

Run BEFORE training. Produces <output_dir>/masks.pt containing:
    M : numpy [L_T, H_T, C]  -- binary masks per (layer, head, category)
    z : numpy [L_T, H_T, C]  -- raw mean saliency (for debugging)

Usage:
    python scripts/01_extract_calibration.py --config config.yaml
"""
import argparse
import os
import yaml
import numpy as np
import torch
from torch.utils.data import DataLoader
from transformers import AutoProcessor, AutoModelForVision2Seq

from circuit_vlm.data.mementos_dataset import MementosDataset, collate
from circuit_vlm.circuit.hooks import register_head_hooks
from circuit_vlm.circuit.importance import (
    ImportanceAccumulator,
    compute_saliency,
    pool_per_head_to_frames,
    build_masks,
)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    args = ap.parse_args()
    cfg = yaml.safe_load(open(args.config))

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    dtype = torch.float16 if cfg.get("fp16", True) else torch.float32

    proc = AutoProcessor.from_pretrained(cfg["teacher_model"])
    teacher = AutoModelForVision2Seq.from_pretrained(
        cfg["teacher_model"], torch_dtype=dtype
    ).to(device)
    teacher.eval()
    # We need gradients w.r.t. attention activations, NOT parameters.
    for p in teacher.parameters():
        p.requires_grad = False

    text_cfg = teacher.config.text_config if hasattr(teacher.config, "text_config") else teacher.config
    L_T, H_T = text_cfg.num_hidden_layers, text_cfg.num_attention_heads

    dataset = MementosDataset(cfg["mementos_root"], cfg["calibration_split"],
                              proc, max_frames=cfg["max_frames"])
    loader = DataLoader(dataset, batch_size=1, shuffle=False, collate_fn=collate)

    capture, handles = register_head_hooks(teacher, H_T)
    accumulator = ImportanceAccumulator(L_T, H_T)

    print(f"Calibrating on {len(dataset)} sequences "
          f"(capping at {cfg['calibration_batches']})...")

    for step, batch in enumerate(loader):
        if step >= cfg["calibration_batches"]:
            break
        capture.clear()

        input_ids = batch["input_ids"].to(device)
        labels = batch["labels"].to(device)
        attention_mask = batch["attention_mask"].to(device)
        pixel_values = torch.cat([pv for pv in batch["pixel_values"]], dim=0).to(device, dtype=dtype)

        # Important: we need grads w.r.t. ACTIVATIONS (the per-head outputs),
        # so we have to ask the captured tensors to require grad. The cleanest
        # way is to enable grad on the forward and let autograd propagate
        # through teacher attentions. Activations need .requires_grad_() if
        # they are leaves, but here they're computed inside the model, so
        # autograd already tracks them as long as inputs do. We bypass the
        # `no_grad` and instead freeze params.
        for t in capture.per_head_outputs.values():
            t.requires_grad_(True)

        out = teacher(
            input_ids=input_ids,
            pixel_values=pixel_values,
            attention_mask=attention_mask,
            labels=labels,
            return_dict=True,
        )
        # Need .retain_grad() on each captured tensor BEFORE backward
        for t in capture.per_head_outputs.values():
            t.retain_grad()
        out.loss.backward()

        # For each layer: compute saliency at frame granularity, update z[l,:,c]
        cats = batch["frame_categories"]
        if any(c is None for c in cats):
            raise RuntimeError(
                "Calibration data must have frame_categories. "
                "Run data/calibration_labels.py first."
            )

        for l, ph in capture.per_head_outputs.items():
            grads = ph.grad                                      # [B, T, H, D]
            if grads is None:
                continue
            pooled_act = pool_per_head_to_frames(ph.detach(), batch["frame_spans"])
            pooled_grad = pool_per_head_to_frames(grads.detach(), batch["frame_spans"])
            sal = compute_saliency(pooled_act, pooled_grad)      # [B, F, H]
            accumulator.update(l, sal, cats)

        teacher.zero_grad(set_to_none=True)

        if step % 25 == 0:
            print(f"  calib step {step}/{cfg['calibration_batches']}")

    z = accumulator.finalize()                                   # [L, H, C]
    M = build_masks(z, cfg["top_k_percent"])

    os.makedirs(cfg["output_dir"], exist_ok=True)
    out_path = os.path.join(cfg["output_dir"], "masks.pt")
    torch.save({"M": M, "z": z}, out_path)
    print(f"Saved masks to {out_path}")
    print(f"z stats: min={z.min():.4f} mean={z.mean():.4f} max={z.max():.4f}")
    for c, name in enumerate(["Object", "Behavior", "Other"]):
        active = M[..., c].sum()
        print(f"  {name}: {int(active)} active heads out of {L_T * H_T}")

    for h in handles:
        h.remove()


if __name__ == "__main__":
    main()
