"""
Auto-generate per-frame {Object / Behavior / Other} labels for the calibration set.

Pipeline:
  1. For each Mementos sequence, call the GPT-4 keyword extractor (already provided
     by the Mementos repo) on the *reference caption* to get:
        objects:   ['dog', 'frisbee', ...]
        behaviors: ['catch', 'run', ...]
  2. Run the teacher once on (frames, caption) and record cross-attention from each
     keyword's text token to the visual tokens of each frame.
        - Object keyword -> assign to frame with max attention.
        - Behavior keyword -> assign to the pair (f, f+1) with max summed attention;
          we tag frame f as Behavior (the *onset* frame).
  3. For each frame f, the category is:
        Behavior  if f is tagged as a behavior onset,
        Object    elif f has an object assigned,
        Other     otherwise.

This replaces hand-labeling. It runs once, offline, on the calibration split.
"""
from __future__ import annotations
from typing import Dict, List, Tuple
import json

import torch

from ..circuit.importance import CAT_OBJECT, CAT_BEHAVIOR, CAT_OTHER


def extract_keywords_via_gpt4(caption: str, gpt4_fn) -> Tuple[List[str], List[str]]:
    """
    Thin wrapper around your existing Mementos GPT-4 extractor.
    `gpt4_fn(caption) -> {"objects": [...], "behaviors": [...]}`.
    """
    out = gpt4_fn(caption)
    return out["objects"], out["behaviors"]


def locate_keyword_token_spans(
    caption: str,
    keywords: List[str],
    tokenizer,
) -> Dict[str, List[int]]:
    """
    For each keyword, return the indices (within tokenized caption) where it appears.
    Simple substring match at the token-decoded level.
    """
    enc = tokenizer(caption, return_tensors="pt", add_special_tokens=False)
    ids = enc.input_ids[0].tolist()
    # Decode each token individually to make matching tractable
    decoded = [tokenizer.decode([t]).strip().lower() for t in ids]
    out: Dict[str, List[int]] = {}
    for kw in keywords:
        kw_lower = kw.lower()
        hits = [i for i, tok in enumerate(decoded) if tok and tok in kw_lower or kw_lower in tok]
        out[kw] = hits
    return out


@torch.no_grad()
def assign_frame_categories(
    teacher_model,
    processor,
    sample: dict,                 # output of MementosDataset.__getitem__
    objects: List[str],
    behaviors: List[str],
    caption_offset: int,          # where caption tokens start within input_ids
) -> List[int]:
    """
    Returns a list of length num_frames with category id per frame.

    Uses the teacher's last-layer attention from caption tokens to visual frame tokens.
    """
    device = next(teacher_model.parameters()).device
    input_ids = sample["input_ids"].unsqueeze(0).to(device)
    pixel_values = sample["pixel_values"].to(device)
    attention_mask = torch.ones_like(input_ids)

    out = teacher_model(
        input_ids=input_ids,
        pixel_values=pixel_values,
        attention_mask=attention_mask,
        output_attentions=True,
        return_dict=True,
    )
    # average over heads & last few layers for stability
    attns = out.attentions[-4:]                                  # tuple of [1, H, T, T]
    attn = torch.stack(attns, dim=0).mean(dim=(0, 2))[0]         # [T, T]

    frame_spans = sample["frame_spans"]
    num_frames = sample["num_frames"]
    caption_token_locs = locate_keyword_token_spans(
        sample.get("caption", ""), objects + behaviors, processor.tokenizer,
    )

    # For each keyword, mass each frame receives
    def frame_mass(kw: str) -> torch.Tensor:
        token_idxs = caption_token_locs.get(kw, [])
        token_idxs = [caption_offset + i for i in token_idxs if caption_offset + i < attn.shape[0]]
        if not token_idxs:
            return torch.zeros(num_frames, device=device)
        mass = torch.zeros(num_frames, device=device)
        for f_idx, span in enumerate(frame_spans):
            mass[f_idx] = attn[token_idxs, span.start:span.end].sum()
        return mass

    cats = [CAT_OTHER] * num_frames

    # Behaviors first (they take precedence on their onset frame)
    behavior_frames = set()
    for kw in behaviors:
        mass = frame_mass(kw)
        if mass.sum() == 0:
            continue
        # find pair (f, f+1) with max combined mass
        if num_frames >= 2:
            pair_scores = mass[:-1] + mass[1:]
            best = int(pair_scores.argmax().item())
            behavior_frames.add(best)
        else:
            behavior_frames.add(int(mass.argmax().item()))

    object_frames = set()
    for kw in objects:
        mass = frame_mass(kw)
        if mass.sum() == 0:
            continue
        object_frames.add(int(mass.argmax().item()))

    for f in range(num_frames):
        if f in behavior_frames:
            cats[f] = CAT_BEHAVIOR
        elif f in object_frames:
            cats[f] = CAT_OBJECT
        else:
            cats[f] = CAT_OTHER
    return cats


def write_index_with_categories(
    out_path: str,
    entries: List[dict],
) -> None:
    """Save the augmented index.json (with frame_categories field)."""
    with open(out_path, "w") as f:
        json.dump(entries, f, indent=2)
