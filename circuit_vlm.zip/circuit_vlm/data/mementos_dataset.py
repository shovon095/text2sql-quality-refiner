"""
Mementos dataset.

Each sample produces:
    - pixel_values: [N_frames, 3, H, W]
    - input_ids:    LM input (image placeholders + prompt + caption)
    - labels:       loss-bearing on caption tokens only
    - frame_spans:  list[FrameSpan] giving the slice of `input_ids` that each frame
                    occupies AFTER the processor expands <image> placeholders into
                    visual tokens
    - frame_categories: list[int] in {0,1,2} (Object/Behavior/Other) for calibration
                        runs; can be None during distillation training

NOTE: frame_span computation is processor-specific. For LLaVA-1.5 each <image> token
becomes (image_size/patch_size)^2 visual tokens at a known position. We expose a
helper `compute_llava_frame_spans` for that case.
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Dict
import json

import torch
from torch.utils.data import Dataset
from PIL import Image

from ..circuit.importance import FrameSpan, CAT_OBJECT, CAT_BEHAVIOR, CAT_OTHER


@dataclass
class MementosSample:
    sequence_id: str
    frames: List[Image.Image]
    caption: str
    frame_categories: Optional[List[int]] = None     # per-frame label if calibration


class MementosDataset(Dataset):
    """
    Expects `index.json` of the form:
        [
          {"id": "...", "frames": ["f0.jpg", "f1.jpg", ...],
           "caption": "...", "frame_categories": [0,1,1,2]},
          ...
        ]
    """
    def __init__(self, root: str, split: str, processor, max_frames: int = 8):
        self.root = Path(root) / split
        self.processor = processor
        self.max_frames = max_frames
        with open(self.root / "index.json") as f:
            self.entries = json.load(f)

    def __len__(self):
        return len(self.entries)

    def __getitem__(self, idx: int) -> Dict:
        entry = self.entries[idx]
        frames = [Image.open(self.root / p).convert("RGB")
                  for p in entry["frames"][:self.max_frames]]
        caption = entry["caption"]
        cats = entry.get("frame_categories")
        if cats is not None:
            cats = cats[:self.max_frames]

        # Build the chat prompt — LLaVA / TinyLLaVA style
        prompt = (
            "USER: " + ("<image>\n" * len(frames)) +
            "Describe what happens across these frames.\nASSISTANT:"
        )
        full_text = prompt + " " + caption

        # Tokenize + process images
        inputs = self.processor(
            text=full_text,
            images=frames,
            return_tensors="pt",
            padding=False,
        )
        input_ids = inputs["input_ids"][0]
        pixel_values = inputs["pixel_values"]

        # Labels: mask everything before "ASSISTANT:" — only the caption is loss-bearing
        prompt_ids = self.processor.tokenizer(prompt, return_tensors="pt").input_ids[0]
        labels = input_ids.clone()
        labels[: len(prompt_ids)] = -100

        # Compute frame_spans on the *expanded* input_ids (image tokens are already
        # expanded by the LlavaProcessor). We locate each contiguous run of
        # image-token-id and call it one frame.
        image_token_id = self.processor.tokenizer.convert_tokens_to_ids(
            getattr(self.processor, "image_token", "<image>")
        )
        frame_spans = _runs_of_token(input_ids.tolist(), image_token_id)
        assert len(frame_spans) == len(frames), (
            f"frame_span count {len(frame_spans)} != frame count {len(frames)}"
        )

        return {
            "input_ids": input_ids,
            "labels": labels,
            "pixel_values": pixel_values,
            "frame_spans": frame_spans,
            "frame_categories": cats,
            "num_frames": len(frames),
        }


def _runs_of_token(ids: List[int], token_id: int) -> List[FrameSpan]:
    """Return contiguous runs of `token_id` in `ids` as FrameSpans."""
    spans = []
    i = 0
    n = len(ids)
    while i < n:
        if ids[i] == token_id:
            j = i
            while j < n and ids[j] == token_id:
                j += 1
            spans.append(FrameSpan(start=i, end=j))
            i = j
        else:
            i += 1
    return spans


def collate(batch):
    """
    Right-pad input_ids and labels; stack pixel_values along frame dim with padding;
    keep frame_spans / frame_categories as lists.
    """
    from torch.nn.utils.rnn import pad_sequence
    input_ids = pad_sequence([b["input_ids"] for b in batch], batch_first=True, padding_value=0)
    labels = pad_sequence([b["labels"] for b in batch], batch_first=True, padding_value=-100)
    attention_mask = (input_ids != 0).long()
    # pixel_values: list of [N_f, 3, H, W] -- variable N_f
    pixel_values = [b["pixel_values"] for b in batch]
    frame_spans = [b["frame_spans"] for b in batch]
    frame_categories = [b["frame_categories"] for b in batch]
    num_frames = [b["num_frames"] for b in batch]
    return {
        "input_ids": input_ids,
        "labels": labels,
        "attention_mask": attention_mask,
        "pixel_values": pixel_values,
        "frame_spans": frame_spans,
        "frame_categories": frame_categories,
        "num_frames": num_frames,
    }
