"""
Learnable per-layer projections W_l: R^{D_S} -> R^{D_T}.

One projection per *teacher* layer (since the depth map collapses several teacher
layers onto the same student layer, each teacher layer still needs its own W_l).
"""
import torch
import torch.nn as nn


class LayerwiseProjection(nn.Module):
    def __init__(self, num_teacher_layers: int, d_student: int, d_teacher: int):
        super().__init__()
        self.num_teacher_layers = num_teacher_layers
        self.projs = nn.ModuleList([
            nn.Linear(d_student, d_teacher, bias=False)
            for _ in range(num_teacher_layers)
        ])
        for p in self.projs:
            nn.init.xavier_uniform_(p.weight)

    def forward(self, x: torch.Tensor, layer_idx: int) -> torch.Tensor:
        return self.projs[layer_idx](x)
