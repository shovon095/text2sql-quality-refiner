"""
Main training loop for circuit-guided KD on Mementos.

For each step:
  1. Forward teacher (frozen, no_grad) with hooks -> per-head A^T_{l,h}
  2. Forward student with hooks -> per-head A^S_{l',h'}
  3. Pool to frames, build C^T_l, C^S_{f(l)}, Delta^T, Delta^S
  4. Compute L_CE (student LM), L_KD (logit KL), L_point, L_trans, L_dir
  5. Backprop on the student (+ projections)
"""
from __future__ import annotations
from typing import Dict, List
import os
import yaml
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from transformers import AutoProcessor, AutoModelForVision2Seq, get_linear_schedule_with_warmup

from ..data.mementos_dataset import MementosDataset, collate
from ..circuit.hooks import register_head_hooks, AttentionCapture
from ..circuit.importance import FrameSpan, merge_category_mask_per_frame
from ..circuit.construction import (
    build_teacher_circuit,
    build_student_circuit,
    adjacent_transition,
    depth_map,
)
from ..losses.circuit_losses import (
    loss_point,
    loss_trans,
    loss_direction,
    loss_kd_logits,
)
from .projections import LayerwiseProjection


def _shift_labels_for_lm(labels: torch.Tensor) -> torch.Tensor:
    """Standard left-shift for causal LM loss-bearing mask."""
    return (labels[:, 1:] != -100)


def _filter_caption_logits(logits: torch.Tensor, labels: torch.Tensor):
    """Return shifted (logits, mask) so loss is computed only on response tokens."""
    s_logits = logits[:, :-1, :].contiguous()
    s_labels = labels[:, 1:].contiguous()
    mask = (s_labels != -100)
    return s_logits, s_labels, mask


def train(config_path: str):
    cfg = yaml.safe_load(open(config_path))
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # ---------- processors / models ----------
    teacher_proc = AutoProcessor.from_pretrained(cfg["teacher_model"])
    student_proc = AutoProcessor.from_pretrained(cfg["student_model"])

    dtype = torch.float16 if cfg.get("fp16", True) else torch.float32
    teacher = AutoModelForVision2Seq.from_pretrained(
        cfg["teacher_model"], torch_dtype=dtype
    ).to(device).eval()
    for p in teacher.parameters():
        p.requires_grad = False

    student = AutoModelForVision2Seq.from_pretrained(
        cfg["student_model"], torch_dtype=dtype
    ).to(device).train()

    # ---------- discover dimensions ----------
    t_cfg = teacher.config.text_config if hasattr(teacher.config, "text_config") else teacher.config
    s_cfg = student.config.text_config if hasattr(student.config, "text_config") else student.config
    L_T, H_T = t_cfg.num_hidden_layers, t_cfg.num_attention_heads
    L_S, H_S = s_cfg.num_hidden_layers, s_cfg.num_attention_heads
    D_T, D_S = t_cfg.hidden_size, s_cfg.hidden_size

    print(f"Teacher: L={L_T} H={H_T} D={D_T} | Student: L={L_S} H={H_S} D={D_S}")

    # ---------- precomputed masks (from 01_extract_calibration.py) ----------
    masks_path = os.path.join(cfg["output_dir"], "masks.pt")
    mask_data = torch.load(masks_path)
    M = mask_data["M"]                          # numpy [L_T, H_T, C]
    print(f"Loaded masks shape={M.shape}")

    # ---------- data ----------
    dataset = MementosDataset(cfg["mementos_root"], cfg["train_split"], teacher_proc,
                              max_frames=cfg["max_frames"])
    loader = DataLoader(dataset, batch_size=cfg["batch_size"], shuffle=True,
                        collate_fn=collate, num_workers=2)

    # ---------- projections + optimizer ----------
    projection = LayerwiseProjection(L_T, D_S, D_T).to(device).to(dtype)
    params = list(student.parameters()) + list(projection.parameters())
    optim = torch.optim.AdamW([p for p in params if p.requires_grad],
                              lr=cfg["learning_rate"])
    sched = get_linear_schedule_with_warmup(
        optim,
        num_warmup_steps=100,
        num_training_steps=cfg["num_epochs"] * len(loader) // cfg["grad_accum_steps"],
    )

    # ---------- hooks ----------
    t_cap, t_handles = register_head_hooks(teacher, H_T)
    s_cap, s_handles = register_head_hooks(student, H_S)

    # ---------- training loop ----------
    step = 0
    for epoch in range(cfg["num_epochs"]):
        for batch in loader:
            # All samples in this minibatch must share frame_categories that match
            # the precomputed masks; if categories are absent at training time,
            # we use a heuristic: every frame -> Other. The point is the masks
            # already encode task-aware structure.
            B = batch["input_ids"].shape[0]
            num_frames = batch["num_frames"]

            # Default to "Other" per frame at training time (masks still differ by cat
            # if we have categories; otherwise we use the union mask).
            frame_cats = batch["frame_categories"]
            if any(c is None for c in frame_cats):
                # Use UNION of all category masks at training-time
                # (M_union[l,h] = max over c of M[l,h,c])
                import numpy as np
                M_union = M.max(axis=-1)                 # [L_T, H_T]
                frame_mask_per_layer = torch.from_numpy(
                    M_union[None, None, :, :].repeat(B, axis=0).repeat(max(num_frames), axis=1)
                )                                        # [B, F, L_T, H_T]
            else:
                frame_mask_per_layer = merge_category_mask_per_frame(M, frame_cats)

            # --- prep inputs (move to device) ---
            input_ids = batch["input_ids"].to(device)
            attention_mask = batch["attention_mask"].to(device)
            labels = batch["labels"].to(device)
            # pixel_values list-of-tensors -> stack with padding along frame dim
            # For LLaVA-1.5 batch_size=1 keeps this simple; for >1 you must pad frames.
            pixel_values = torch.cat([pv for pv in batch["pixel_values"]], dim=0).to(device, dtype=dtype)

            # --- teacher forward (no grad) ---
            t_cap.clear()
            with torch.no_grad():
                t_out = teacher(
                    input_ids=input_ids,
                    pixel_values=pixel_values,
                    attention_mask=attention_mask,
                    output_hidden_states=False,
                    return_dict=True,
                )
            teacher_logits = t_out.logits

            # --- student forward (grad) ---
            s_cap.clear()
            s_out = student(
                input_ids=input_ids,
                pixel_values=pixel_values,
                attention_mask=attention_mask,
                labels=labels,
                return_dict=True,
            )
            student_logits = s_out.logits
            L_ce = s_out.loss

            # --- build circuits per teacher layer ---
            C_T_layers, C_S_layers = [], []
            dT_layers,  dS_layers  = [], []
            for l in range(L_T):
                per_head_T = t_cap.per_head_outputs[l]                # [B, T, H_T, D_T/H_T]
                cT = build_teacher_circuit(
                    per_head_T,
                    batch["frame_spans"],
                    frame_mask_per_layer.to(device),
                    layer_idx=l,
                )                                                     # [B, F, D_T_pooled]
                # NOTE: the per-head outputs above have last dim = D_T/H_T. To get
                # back to D_T we concatenate heads instead of summing -- but our
                # Eq. 4 sums over heads, so the circuit dim is D_T/H_T. Same for
                # student: D_S/H_S. We project that smaller dim with W_l.
                C_T_layers.append(cT)

                l_s = depth_map(l, L_T, L_S)
                per_head_S = s_cap.per_head_outputs[l_s]              # [B, T, H_S, D_S/H_S]
                cS = build_student_circuit(per_head_S, batch["frame_spans"])
                C_S_layers.append(cS)

                if cT.shape[1] >= 2:
                    dT_layers.append(adjacent_transition(cT))
                    dS_layers.append(adjacent_transition(cS))

            # NOTE: projection input dim must equal D_S/H_S, output dim D_T/H_T.
            # We rebuild projection once we know these head-dims (see scripts/02_train).

            # --- losses ---
            L_point = loss_point(C_T_layers, C_S_layers, projection, num_frames)
            if dT_layers:
                L_trans = loss_trans(dT_layers, dS_layers, projection, num_frames)
                L_dir   = loss_direction(dT_layers, dS_layers, projection, num_frames)
            else:
                L_trans = torch.tensor(0.0, device=device)
                L_dir   = torch.tensor(0.0, device=device)

            # Logit KD on caption tokens only
            s_lg, _, mask = _filter_caption_logits(student_logits, labels)
            t_lg, _, _    = _filter_caption_logits(teacher_logits, labels)
            # NOTE: assumes shared vocab. For LLaVA-1.5 -> TinyLLaVA both use LLaMA tokenizer.
            # If vocab sizes differ, truncate to min-V.
            V = min(s_lg.shape[-1], t_lg.shape[-1])
            L_kd = loss_kd_logits(s_lg[..., :V], t_lg[..., :V], mask, cfg["kd_temperature"])

            L_total = (
                cfg["lambda_ce"]    * L_ce
                + cfg["lambda_kd"]    * L_kd
                + cfg["lambda_point"] * L_point
                + cfg["lambda_trans"] * L_trans
                + cfg["lambda_dir"]   * L_dir
            ) / cfg["grad_accum_steps"]

            L_total.backward()

            if (step + 1) % cfg["grad_accum_steps"] == 0:
                torch.nn.utils.clip_grad_norm_(params, cfg["max_grad_norm"])
                optim.step()
                sched.step()
                optim.zero_grad()

            if step % 20 == 0:
                print(f"[ep {epoch} step {step}] "
                      f"L_ce={L_ce.item():.3f} L_kd={L_kd.item():.3f} "
                      f"L_point={L_point.item():.3f} L_trans={L_trans.item():.3f} "
                      f"L_dir={L_dir.item():.3f}")
            step += 1

    for h in t_handles + s_handles:
        h.remove()

    out = os.path.join(cfg["output_dir"], "student_final")
    student.save_pretrained(out)
    student_proc.save_pretrained(out)
    print(f"Saved student to {out}")
