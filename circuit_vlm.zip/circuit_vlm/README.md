# Task-Aware Circuit-Guided KD for Vision-Language (Mementos)

Adapts the CMED BioNER circuit-distillation framework to MLLM sequential image reasoning.

Teacher: LLaVA-1.5-7B    Student: TinyLLaVA-1.5B (or similar)

## Layout
```
circuit_vlm/
├── data/
│   ├── mementos_dataset.py        # PyTorch dataset, frame-aware collation
│   └── calibration_labels.py      # GPT-4 keywords -> per-frame Object/Behavior/Other masks
├── circuit/
│   ├── hooks.py                   # capture per-head attention outputs (teacher & student)
│   ├── importance.py              # task-aware head importance (Eq. 1-3 of CMED paper)
│   └── construction.py            # build C_l(f) and Delta_l(f) at frame granularity
├── losses/
│   ├── circuit_losses.py          # L_point, L_trans, L_dir
│   └── total.py                   # combined objective with KD + CE
├── training/
│   ├── trainer.py                 # main training loop
│   └── projections.py             # learnable W_l (student -> teacher dim)
├── scripts/
│   ├── 01_extract_calibration.py  # one-shot: build masks from calibration set
│   ├── 02_train.py                # full training
│   └── 03_eval_mementos.py        # GPT-4 assisted eval
└── config.yaml
```

## Pipeline
1. `scripts/01_extract_calibration.py` — runs the teacher once over the calibration set, extracts task-aware head masks per BIO-analog category (Object / Behavior / Other), saves to `masks.pt`.
2. `scripts/02_train.py` — trains the student with L_total.
3. `scripts/03_eval_mementos.py` — runs Mementos' GPT-4 keyword eval.
