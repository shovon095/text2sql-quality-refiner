"""
Circuit construction (training time) for teacher and student.

Teacher circuit (Eq. 4):
    C^T_l(f) = sum_h M[l,h,c(f)] * A^T_{l,h}(f) / max(sum_h M[l,h,c(f)], 1)
Student circuit (Eq. 5):
    C^S_{l'}(f) = (1/H_S) * sum_{h'} A^S_{l',h'}(f)
Depth map (Eq. 6):
    l' = floor((l-1) * L_S / L_T) + 1   (1-indexed); we keep 0-indexed here.
Transitions (Eqs. 7-8):
    Delta_l(f) = C_l(f+1) - C_l(f)
"""
from __future__ import annotations
from typing import List

import torch

from .importance import FrameSpan, pool_per_head_to_frames


def depth_map(l_teacher: int, L_T: int, L_S: int) -> int:
    """0-indexed depth mapping. Returns the student layer for a given teacher layer."""
    return min(int(round(l_teacher * L_S / L_T)), L_S - 1)


def build_teacher_circuit(
    per_head: torch.Tensor,            # [B, T, H_T, D_T]
    frame_spans: List[List[FrameSpan]],
    mask_per_frame: torch.Tensor,      # [B, F_max, L, H_T], for THIS layer use mask_per_frame[..., l, :]
    layer_idx: int,
) -> torch.Tensor:
    """
    Returns C^T_l of shape [B, F_max, D_T].
    """
    pooled = pool_per_head_to_frames(per_head, frame_spans)   # [B, F, H, D]
    B, F, H, D = pooled.shape
    mask = mask_per_frame[..., layer_idx, :].to(pooled.device).to(pooled.dtype)  # [B, F, H]
    # weighted sum over heads
    weighted = (mask.unsqueeze(-1) * pooled).sum(dim=2)        # [B, F, D]
    denom = mask.sum(dim=2, keepdim=True).clamp(min=1.0)       # [B, F, 1]
    return weighted / denom


def build_student_circuit(
    per_head: torch.Tensor,            # [B, T, H_S, D_S]
    frame_spans: List[List[FrameSpan]],
) -> torch.Tensor:
    """
    Returns C^S_{l'} of shape [B, F_max, D_S]  (uniform mean over heads).
    """
    pooled = pool_per_head_to_frames(per_head, frame_spans)    # [B, F, H, D]
    return pooled.mean(dim=2)                                   # [B, F, D]


def adjacent_transition(C: torch.Tensor) -> torch.Tensor:
    """
    Eqs. (7)/(8): Delta(f) = C(f+1) - C(f), shape [B, F-1, D].
    """
    return C[:, 1:] - C[:, :-1]


def multiscale_transition(C: torch.Tensor, ks=(1, 2)) -> List[torch.Tensor]:
    """
    Multi-scale extension for VLM (not in CMED paper). Returns list of [B, F-k, D].
    """
    return [C[:, k:] - C[:, :-k] for k in ks if C.shape[1] > k]
