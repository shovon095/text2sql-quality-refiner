"""
Task-aware head importance for VLMs at FRAME granularity.

Mirrors Eqs. (1)-(3) of the CMED paper, but with categories
    {Object, Behavior, Other}  (the BIO analog for Mementos)
and "tokens" replaced by "frames" — i.e., we pool the visual-token attention
outputs of each frame into a single per-frame activation before scoring.

Pipeline (offline, on a calibration set):
  for batch in calibration_loader:
      forward + backward(loss)               # populates A and gradients
      for each layer l, head h, frame f:
          s_{l,h}(b,f) = || A_{l,h}(b,f) * grad_A_{l,h}(b,f) ||_1   # Eq. 1
      accumulate s into per-category buckets using frame labels c(f) in {Obj, Beh, Other}
  z[l,h,c] = mean of s over all frames labeled c                    # Eq. 2
  M[l,h,c] = 1 if z[l,h,c] >= percentile_{100-k}(z[:,:,c]) else 0   # Eq. 3
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List

import numpy as np
import torch

# Category indices — keep these constant project-wide
CAT_OBJECT = 0
CAT_BEHAVIOR = 1
CAT_OTHER = 2
NUM_CATEGORIES = 3
CATEGORY_NAMES = ["Object", "Behavior", "Other"]


@dataclass
class FrameSpan:
    """The slice of LM input tokens that correspond to a single image frame."""
    start: int   # inclusive
    end: int     # exclusive

    def __len__(self):
        return self.end - self.start


def pool_per_head_to_frames(
    per_head: torch.Tensor,                  # [B, T, H, D]
    frame_spans: List[List[FrameSpan]],      # frame_spans[b] = list of spans for sample b
) -> torch.Tensor:
    """
    Mean-pool per-head activations over the visual tokens of each frame.
    Returns tensor of shape [B, F_max, H, D] with zero-padding for shorter sequences.
    """
    B, T, H, D = per_head.shape
    F_max = max(len(spans) for spans in frame_spans)
    out = per_head.new_zeros(B, F_max, H, D)
    for b, spans in enumerate(frame_spans):
        for f_idx, span in enumerate(spans):
            if span.end > span.start:
                out[b, f_idx] = per_head[b, span.start:span.end].mean(dim=0)
    return out


def compute_saliency(
    activations: torch.Tensor,    # [B, F, H, D]
    gradients: torch.Tensor,      # [B, F, H, D]
) -> torch.Tensor:
    """
    Eq. (1): s_{l,h}(b, f) = || A_{l,h}(b, f) ⊙ g_{l,h}(b, f) ||_1
    Returns [B, F, H].
    """
    return (activations * gradients).abs().sum(dim=-1)


class ImportanceAccumulator:
    """
    Online accumulator for z[l, h, c] = mean saliency over frames of category c.
    Maintains running sum and count per (layer, head, category).
    """

    def __init__(self, num_layers: int, num_heads: int):
        self.num_layers = num_layers
        self.num_heads = num_heads
        # sums[l] : [H, C], counts[l] : [C]
        self.sums = [np.zeros((num_heads, NUM_CATEGORIES), dtype=np.float64)
                     for _ in range(num_layers)]
        self.counts = np.zeros(NUM_CATEGORIES, dtype=np.int64)

    def update(
        self,
        layer_idx: int,
        saliency: torch.Tensor,                      # [B, F, H]
        frame_categories: List[List[int]],           # frame_categories[b][f] in {0,1,2}
    ):
        s = saliency.detach().float().cpu().numpy()
        B, F, H = s.shape
        for b in range(B):
            cats = frame_categories[b]
            for f in range(min(F, len(cats))):
                c = cats[f]
                self.sums[layer_idx][:, c] += s[b, f]
                if layer_idx == 0:
                    # count frames only once across layers
                    self.counts[c] += 1

    def finalize(self) -> np.ndarray:
        """
        Returns z of shape [L, H, C] = mean saliency per (layer, head, category).
        """
        L, H, C = self.num_layers, self.num_heads, NUM_CATEGORIES
        z = np.zeros((L, H, C), dtype=np.float64)
        safe_counts = np.maximum(self.counts, 1)
        for l in range(L):
            z[l] = self.sums[l] / safe_counts[None, :]
        return z


def build_masks(z: np.ndarray, top_k_percent: float) -> np.ndarray:
    """
    Eq. (3): for each category c, keep heads whose z >= percentile_{100-k}(z[:,:,c]).
    Returns mask of shape [L, H, C] in {0, 1}.
    """
    L, H, C = z.shape
    M = np.zeros_like(z, dtype=np.float32)
    for c in range(C):
        thresh = np.percentile(z[:, :, c], 100.0 - top_k_percent)
        M[:, :, c] = (z[:, :, c] >= thresh).astype(np.float32)
    return M


def merge_category_mask_per_frame(
    M: np.ndarray,                            # [L, H, C]
    frame_categories: List[List[int]],        # per-sample, per-frame category id
) -> torch.Tensor:
    """
    For Eq. (4) of the paper we need, for each frame f, the mask M[:, :, c(f)].
    Returns tensor of shape [B, F_max, L, H].
    """
    L, H, C = M.shape
    B = len(frame_categories)
    F_max = max(len(c) for c in frame_categories)
    out = np.zeros((B, F_max, L, H), dtype=np.float32)
    for b in range(B):
        for f, c in enumerate(frame_categories[b]):
            out[b, f] = M[:, :, c]
    return torch.from_numpy(out)
