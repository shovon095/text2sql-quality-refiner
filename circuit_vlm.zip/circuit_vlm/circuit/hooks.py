"""
Forward hooks to capture per-head attention outputs A_{l,h}(b, t) from HuggingFace
transformer layers (works for LLaMA/LLaVA-style architectures).

We hook the attention module's `o_proj` input — that is the concatenated per-head
output BEFORE the output projection, shape [B, T, num_heads * head_dim]. We reshape
to [B, T, num_heads, head_dim] to recover per-head activations.

This is the cleanest way to get A_{l,h} without modifying model code.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List

import torch
import torch.nn as nn


@dataclass
class AttentionCapture:
    """Per-layer, per-head attention outputs captured during a forward pass."""
    # layer_idx -> tensor of shape [B, T, H, D_head]
    per_head_outputs: Dict[int, torch.Tensor] = field(default_factory=dict)

    def clear(self):
        self.per_head_outputs.clear()


class HeadOutputHook:
    """
    Forward pre-hook on `o_proj`. The input to o_proj is the concatenated per-head
    output: shape [B, T, num_heads * head_dim]. We reshape and store.
    """

    def __init__(self, capture: AttentionCapture, layer_idx: int, num_heads: int):
        self.capture = capture
        self.layer_idx = layer_idx
        self.num_heads = num_heads

    def __call__(self, module: nn.Module, inputs):
        # inputs is a tuple; first element is the hidden tensor going into o_proj
        x = inputs[0]                                # [B, T, H*D]
        B, T, HD = x.shape
        D = HD // self.num_heads
        per_head = x.view(B, T, self.num_heads, D)   # [B, T, H, D]
        # Detach for the teacher (importance extraction); the student version
        # below uses retain_grad=False but registers leaves so grads flow through
        self.capture.per_head_outputs[self.layer_idx] = per_head
        return None  # don't modify input


def find_attention_modules(model: nn.Module) -> List[nn.Module]:
    """
    Walk the LLM decoder layers and return the attention module of each layer.
    Handles LLaVA/TinyLLaVA which wrap a LLaMA-family LM inside `model.language_model`
    or expose `model.model.layers` directly.
    """
    # Try common attribute paths
    paths = [
        ("language_model", "model", "layers"),
        ("model", "layers"),
        ("transformer", "h"),
    ]
    layers = None
    for path in paths:
        obj = model
        ok = True
        for attr in path:
            if hasattr(obj, attr):
                obj = getattr(obj, attr)
            else:
                ok = False
                break
        if ok:
            layers = obj
            break
    if layers is None:
        raise RuntimeError("Could not locate decoder layers in model.")

    attn_modules = []
    for layer in layers:
        # LLaMA-style: layer.self_attn
        if hasattr(layer, "self_attn"):
            attn_modules.append(layer.self_attn)
        elif hasattr(layer, "attn"):
            attn_modules.append(layer.attn)
        else:
            raise RuntimeError(f"Unknown attention attr in layer {layer}")
    return attn_modules


def register_head_hooks(model: nn.Module, num_heads: int) -> tuple[AttentionCapture, list]:
    """
    Register hooks on every decoder layer's o_proj. Returns the capture object and
    a list of hook handles (call .remove() on each to detach).
    """
    capture = AttentionCapture()
    handles = []
    attn_modules = find_attention_modules(model)
    for layer_idx, attn in enumerate(attn_modules):
        # LLaMA/LLaVA use `o_proj`; some others use `out_proj` or `c_proj`
        o_proj = None
        for name in ("o_proj", "out_proj", "c_proj"):
            if hasattr(attn, name):
                o_proj = getattr(attn, name)
                break
        if o_proj is None:
            raise RuntimeError(f"No output projection found in layer {layer_idx}")
        hook = HeadOutputHook(capture, layer_idx, num_heads)
        handle = o_proj.register_forward_pre_hook(hook)
        handles.append(handle)
    return capture, handles
